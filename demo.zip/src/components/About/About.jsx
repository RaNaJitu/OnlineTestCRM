import { React } from 'react';
const About = () => {
    return (
      <div className="container">
        <div className="py-4">
          <h1>About Page</h1>
          <p className="lead">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis
            fugiat aliquam excepturi omnis suscipit aliquid ex ad consequuntur,
            eos corrupti accusantium, nemo voluptates blanditiis! Provident modi
            delectus soluta ad voluptates?
          </p>
          <p className="lead">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis
            fugiat aliquam excepturi omnis suscipit aliquid ex ad consequuntur,
            eos corrupti accusantium, nemo voluptates blanditiis! Provident modi
            delectus soluta ad voluptates?
          </p>
          <p className="lead">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis
            fugiat aliquam excepturi omnis suscipit aliquid ex ad consequuntur,
            eos corrupti accusantium, nemo voluptates blanditiis! Provident modi
            delectus soluta ad voluptates?
          </p>
          <p className="lead">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis
            fugiat aliquam excepturi omnis suscipit aliquid ex ad consequuntur,
            eos corrupti accusantium, nemo voluptates blanditiis! Provident modi
            delectus soluta ad voluptates?
          </p>
        </div>
      </div>
    );
}

export default About;